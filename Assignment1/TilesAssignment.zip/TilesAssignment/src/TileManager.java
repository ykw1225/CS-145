
import java.awt.*;

/**
 * Replace this text with your description of the TileManager class.
 *
 * @author Your Name
 */
public class TileManager {

    // ----- fields: what does a tile manager have? -----

    // Your TileManager class should store a list of tiles as a field of type ArrayList. The various methods listed
    // below will cause changes to the contents of that list. Remember to import java.util.*; to use ArrayList.


    // ----- methods: what can a tile manager do? -----

    public TileManager() {
        // This constructor is called every time a new tile manager object is created. Initially your manager is not
        // storing any tiles.


    }

    public void addTile(Tile rect) {
        //In this method you should add the given tile to the end of your tile manager's list of tiles.


    }

    public void drawAll(Graphics g) {
        // This method should cause all of the tiles in the tile manager to draw themselves on the screen using the
        // given graphical pen. You do not need to do this yourself directly by calling methods on the Graphics object;
        // each Tile object already has a draw method that it can use to draw itself.Draw the tiles from bottom (start)
        // to top (end) of your manager's list.

        // Recall that in order to refer to type Graphics, you must import java.awt. *; in your code.

    }

    // The next four methods are called by the graphical user interface ("GUI") in response to various
    // mouse clicks, passing you the x/y coordinates where the user clicked.If the coordinates passed do not touch
    // any tiles, no action or error should occur. After any click, the GUI will clear the screen for you and call
    // drawAll to re-draw all of the tiles in your list.

    public void raise(int x, int y) {
        // Called when the user left-clicks. It passes you the x/y coordinates the user clicked. If these coordinates
        // touch any tiles, you should move the topmost of these tiles to the very top (end) of the list.


    }

    public void lower(int x, int y) {
        // Called when the user Shift-left-clicks. If these coordinates touch any tiles, you should move the topmost of
        // these tiles to the very bottom (beginning) of the list.


    }

    public void delete(int x, int y) {
        // Called when the user right-clicks. If these coordinates touch any tiles, you should delete the topmost of
        // these tiles from the list.


    }

    public void deleteAll(int x, int y) {
        // Called when the user Shift-right-clicks. If these coordinates touch any tiles, you should delete all such
        // tiles from the list.


    }

    public void shuffle(int width, int height) {
        // Called when the user types S. This method should perform two actions: (1) reordering the tiles in the list
        // into a random order, and (2) moving every tile on the screen to a new random x/y pixel position. The random
        // position should be such that the square's top-left x/y position is non-negative and also such that every
        // pixel of the tile is within the passed width and height. For example, if the width passed is 300 and the
        // height is 200, a tile of size 20x10 must be moved to a random position such that its top-left x/y position
        // is between (0, 0) and (280, 190).

        // You can use the built-in Java method Collections.shuffle to randomly rearrange the elements of your list (step 1).


    }

}
